"use client";

import { useState } from "react";

export default function Home() {
  const [sfen, setSfen] = useState("");
  const [move, setMove] = useState("");
  const [result, setResult] = useState("");

  const handleAnalyze = async () => {
    const res = await fetch("http://localhost:8000/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sfen, move }),
    });
    const data = await res.json();
    setResult(`🧠 AI: ${data.ai_output}\n💬 ChatGPT: ${data.comment}`);
  };

  return (
    <main className="p-10 font-sans">
      <h1 className="text-3xl font-bold mb-4">振電３ × ChatGPT</h1>
      <div className="space-y-3">
        <input
          className="border p-2 w-full"
          placeholder="局面のSFENを入力"
          value={sfen}
          onChange={(e) => setSfen(e.target.value)}
        />
        <input
          className="border p-2 w-full"
          placeholder="指し手（例: 7g7f）"
          value={move}
          onChange={(e) => setMove(e.target.value)}
        />
        <button
          onClick={handleAnalyze}
          className="bg-blue-500 text-white px-4 py-2 rounded"
        >
          解析する
        </button>
        <pre className="whitespace-pre-wrap mt-4 bg-gray-100 p-3 rounded">
          {result || "結果がここに表示されます"}
        </pre>
      </div>
    </main>
  );
}
