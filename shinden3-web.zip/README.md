# ChatGPT × 振電３ Webアプリ

将棋AI（YaneuraOu）とChatGPTを組み合わせたWebアプリです。

## 🚀 セットアップ

### バックエンド
```bash
cd backend
cp .env.example .env
pip install -r requirements.txt
uvicorn main:app --reload
```

### フロントエンド
```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```

アクセス: [http://localhost:3000](http://localhost:3000)
