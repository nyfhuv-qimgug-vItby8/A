from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
import os, openai, json, subprocess

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

openai.api_key = os.getenv("OPENAI_API_KEY", "sk-yourkey")
ENGINE_PATH = os.getenv("ENGINE_PATH", "./engine/yaneuraou")

@app.get("/")
def index():
    return {"message": "Shinden3 × ChatGPT backend ready"}

@app.post("/analyze")
async def analyze(request: Request):
    data = await request.json()
    sfen = data.get("sfen", "")
    move = data.get("move", "")

    try:
        process = subprocess.Popen(
            [ENGINE_PATH, "usi"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            text=True
        )
        commands = f"position sfen {sfen}\ngo depth 10\n"
        stdout, _ = process.communicate(commands, timeout=5)
        ai_output = stdout.split("bestmove")[-1].strip()
    except Exception as e:
        ai_output = f"(AI error: {e})"

    prompt = f"""
以下は将棋AIが解析した出力です：
{ai_output}

局面: {sfen}
指し手: {move}

この局面の形勢と次の狙いを初心者にも分かりやすく説明してください。
"""

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}]
        )
        comment = response.choices[0].message.content.strip()
    except Exception as e:
        comment = f"(ChatGPT error: {e})"

    return {"ai_output": ai_output, "comment": comment}
